--
-- PostgreSQL database dump
--

\restrict 561UK4z7GOZGPETxf6O54oTPhVALExz1CGBz8tmu10PG3TsXKTBfG3QvSeeTCw4

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: admin_settings; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.admin_settings (
    id integer NOT NULL,
    setting_key character varying(100) NOT NULL,
    setting_value text,
    setting_type character varying(50) DEFAULT 'string'::character varying,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admin_settings OWNER TO nailmastery;

--
-- Name: TABLE admin_settings; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.admin_settings IS 'Настройки админ-панели';


--
-- Name: COLUMN admin_settings.setting_key; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.admin_settings.setting_key IS 'Ключ настройки (уникальный)';


--
-- Name: COLUMN admin_settings.setting_value; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.admin_settings.setting_value IS 'Значение настройки';


--
-- Name: COLUMN admin_settings.setting_type; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.admin_settings.setting_type IS 'Тип настройки (string, boolean, number, json)';


--
-- Name: COLUMN admin_settings.description; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.admin_settings.description IS 'Описание настройки';


--
-- Name: admin_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.admin_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admin_settings_id_seq OWNER TO nailmastery;

--
-- Name: admin_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.admin_settings_id_seq OWNED BY public.admin_settings.id;


--
-- Name: admins; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.admins (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.admins OWNER TO nailmastery;

--
-- Name: TABLE admins; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.admins IS 'Таблица администраторов системы';


--
-- Name: COLUMN admins.email; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.admins.email IS 'Email админа (уникальный)';


--
-- Name: COLUMN admins.password_hash; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.admins.password_hash IS 'Хеш пароля (bcrypt)';


--
-- Name: COLUMN admins.name; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.admins.name IS 'Имя администратора';


--
-- Name: admins_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.admins_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.admins_id_seq OWNER TO nailmastery;

--
-- Name: admins_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.admins_id_seq OWNED BY public.admins.id;


--
-- Name: blog_posts; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.blog_posts (
    id integer NOT NULL,
    slug character varying(255) NOT NULL,
    title character varying(500) NOT NULL,
    excerpt text NOT NULL,
    content text NOT NULL,
    image_url text,
    image_upload_path text,
    author character varying(255) NOT NULL,
    author_avatar text,
    author_bio text,
    date date NOT NULL,
    read_time character varying(50) DEFAULT '5 мин'::character varying NOT NULL,
    category character varying(100) NOT NULL,
    tags text[] DEFAULT '{}'::text[],
    featured boolean DEFAULT false NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    author_avatar_upload_path text,
    author_id integer
);


ALTER TABLE public.blog_posts OWNER TO nailmastery;

--
-- Name: COLUMN blog_posts.author_id; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.blog_posts.author_id IS 'ID автора из таблицы team_members. Если NULL, используется поле author';


--
-- Name: blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.blog_posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.blog_posts_id_seq OWNER TO nailmastery;

--
-- Name: blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.blog_posts_id_seq OWNED BY public.blog_posts.id;


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.contacts (
    id integer NOT NULL,
    type character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    content text NOT NULL,
    href text,
    subtitle text,
    icon character varying(50) NOT NULL,
    display_order integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.contacts OWNER TO nailmastery;

--
-- Name: contacts_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.contacts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contacts_id_seq OWNER TO nailmastery;

--
-- Name: contacts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.contacts_id_seq OWNED BY public.contacts.id;


--
-- Name: course_lessons; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.course_lessons (
    id integer NOT NULL,
    module_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    video_url character varying(500),
    video_upload_path character varying(255),
    preview_video_url character varying(500),
    duration integer,
    materials jsonb DEFAULT '[]'::jsonb,
    is_preview boolean DEFAULT false,
    order_index integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.course_lessons OWNER TO nailmastery;

--
-- Name: TABLE course_lessons; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.course_lessons IS 'Уроки в модулях курса';


--
-- Name: COLUMN course_lessons.description; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_lessons.description IS 'Описание урока';


--
-- Name: COLUMN course_lessons.video_url; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_lessons.video_url IS 'URL видео урока (YouTube, Vimeo и т.д.)';


--
-- Name: COLUMN course_lessons.materials; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_lessons.materials IS 'JSON массив материалов урока: [{"type": "pdf", "url": "...", "name": "..."}]';


--
-- Name: COLUMN course_lessons.is_preview; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_lessons.is_preview IS 'Можно ли смотреть урок без оплаты курса';


--
-- Name: course_lessons_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.course_lessons_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_lessons_id_seq OWNER TO nailmastery;

--
-- Name: course_lessons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.course_lessons_id_seq OWNED BY public.course_lessons.id;


--
-- Name: course_materials; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.course_materials (
    id integer NOT NULL,
    course_id integer NOT NULL,
    name character varying(255) NOT NULL,
    price_info character varying(100),
    link character varying(500),
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.course_materials OWNER TO nailmastery;

--
-- Name: TABLE course_materials; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.course_materials IS 'Необходимые материалы для прохождения курса';


--
-- Name: COLUMN course_materials.name; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_materials.name IS 'Название материала с ценой, например: "Аппарат для маникюра (от 100 €)"';


--
-- Name: course_materials_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.course_materials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_materials_id_seq OWNER TO nailmastery;

--
-- Name: course_materials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.course_materials_id_seq OWNED BY public.course_materials.id;


--
-- Name: course_modules; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.course_modules (
    id integer NOT NULL,
    course_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    order_index integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.course_modules OWNER TO nailmastery;

--
-- Name: TABLE course_modules; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.course_modules IS 'Модули курса';


--
-- Name: COLUMN course_modules.order_index; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_modules.order_index IS 'Порядок модулей в курсе (для сортировки)';


--
-- Name: course_modules_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.course_modules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_modules_id_seq OWNER TO nailmastery;

--
-- Name: course_modules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.course_modules_id_seq OWNED BY public.course_modules.id;


--
-- Name: course_reviews; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.course_reviews (
    id integer NOT NULL,
    course_id integer NOT NULL,
    user_id integer NOT NULL,
    enrollment_id integer,
    rating integer NOT NULL,
    comment text,
    is_approved boolean DEFAULT false,
    is_featured boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT course_reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.course_reviews OWNER TO nailmastery;

--
-- Name: TABLE course_reviews; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.course_reviews IS 'Отзывы пользователей о курсах';


--
-- Name: COLUMN course_reviews.rating; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_reviews.rating IS 'Оценка курса (1-5)';


--
-- Name: COLUMN course_reviews.is_approved; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_reviews.is_approved IS 'Одобрен ли отзыв администратором для публикации';


--
-- Name: COLUMN course_reviews.is_featured; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_reviews.is_featured IS 'Показывать ли отзыв в топе на странице курса';


--
-- Name: course_reviews_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.course_reviews_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_reviews_id_seq OWNER TO nailmastery;

--
-- Name: course_reviews_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.course_reviews_id_seq OWNED BY public.course_reviews.id;


--
-- Name: course_tariffs; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.course_tariffs (
    id integer NOT NULL,
    course_id integer NOT NULL,
    tariff_type character varying(50) NOT NULL,
    name character varying(255) NOT NULL,
    price numeric(10,2) NOT NULL,
    old_price numeric(10,2),
    features jsonb DEFAULT '[]'::jsonb,
    not_included jsonb DEFAULT '[]'::jsonb,
    is_popular boolean DEFAULT false,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    homework_reviews_limit integer,
    curator_support_months integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT course_tariffs_old_price_check CHECK ((old_price >= (0)::numeric)),
    CONSTRAINT course_tariffs_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT course_tariffs_tariff_type_check CHECK (((tariff_type)::text = ANY ((ARRAY['self'::character varying, 'curator'::character varying, 'vip'::character varying])::text[])))
);


ALTER TABLE public.course_tariffs OWNER TO nailmastery;

--
-- Name: TABLE course_tariffs; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.course_tariffs IS 'Тарифы курса (self, curator, vip)';


--
-- Name: COLUMN course_tariffs.tariff_type; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_tariffs.tariff_type IS 'Тип тарифа: self, curator, vip';


--
-- Name: COLUMN course_tariffs.features; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_tariffs.features IS 'JSON массив строк с преимуществами тарифа';


--
-- Name: COLUMN course_tariffs.not_included; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.course_tariffs.not_included IS 'JSON массив строк с тем, чего нет в тарифе';


--
-- Name: course_tariffs_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.course_tariffs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.course_tariffs_id_seq OWNER TO nailmastery;

--
-- Name: course_tariffs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.course_tariffs_id_seq OWNED BY public.course_tariffs.id;


--
-- Name: courses; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.courses (
    id integer NOT NULL,
    slug character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    subtitle character varying(500),
    description text NOT NULL,
    image_url character varying(500),
    image_upload_path character varying(255),
    video_preview_url character varying(500),
    level character varying(50) NOT NULL,
    category character varying(50) NOT NULL,
    duration character varying(100),
    students_count integer DEFAULT 0,
    rating numeric(3,2) DEFAULT 0,
    reviews_count integer DEFAULT 0,
    instructor_id integer,
    is_active boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    is_new boolean DEFAULT false,
    display_order integer DEFAULT 0,
    includes jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT courses_category_check CHECK (((category)::text = ANY ((ARRAY['basics'::character varying, 'hardware'::character varying, 'extension'::character varying, 'design'::character varying])::text[]))),
    CONSTRAINT courses_level_check CHECK (((level)::text = ANY ((ARRAY['beginner'::character varying, 'intermediate'::character varying, 'advanced'::character varying])::text[]))),
    CONSTRAINT courses_rating_check CHECK (((rating >= (0)::numeric) AND (rating <= (5)::numeric)))
);


ALTER TABLE public.courses OWNER TO nailmastery;

--
-- Name: TABLE courses; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.courses IS 'Основная информация о курсах';


--
-- Name: COLUMN courses.slug; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.courses.slug IS 'URL-friendly идентификатор курса (уникальный)';


--
-- Name: COLUMN courses.level; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.courses.level IS 'Уровень сложности: beginner, intermediate, advanced';


--
-- Name: COLUMN courses.category; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.courses.category IS 'Категория курса: basics, hardware, extension, design';


--
-- Name: COLUMN courses.students_count; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.courses.students_count IS 'Количество студентов (обновляется автоматически)';


--
-- Name: COLUMN courses.rating; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.courses.rating IS 'Средний рейтинг курса (0.00 - 5.00)';


--
-- Name: COLUMN courses.includes; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.courses.includes IS 'JSON массив строк с тем, что входит в курс';


--
-- Name: courses_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.courses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courses_id_seq OWNER TO nailmastery;

--
-- Name: courses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.courses_id_seq OWNED BY public.courses.id;


--
-- Name: enrollments; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.enrollments (
    id integer NOT NULL,
    user_id integer NOT NULL,
    course_id integer NOT NULL,
    tariff_id integer NOT NULL,
    status character varying(50) DEFAULT 'active'::character varying,
    purchased_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    expires_at timestamp with time zone,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    progress_percent integer DEFAULT 0,
    lessons_completed integer DEFAULT 0,
    total_lessons integer,
    payment_id character varying(255),
    payment_status character varying(50),
    amount_paid numeric(10,2),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT enrollments_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'failed'::character varying, 'refunded'::character varying])::text[]))),
    CONSTRAINT enrollments_progress_percent_check CHECK (((progress_percent >= 0) AND (progress_percent <= 100))),
    CONSTRAINT enrollments_status_check CHECK (((status)::text = ANY ((ARRAY['active'::character varying, 'completed'::character varying, 'expired'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.enrollments OWNER TO nailmastery;

--
-- Name: TABLE enrollments; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.enrollments IS 'Записи пользователей на курсы';


--
-- Name: COLUMN enrollments.status; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.enrollments.status IS 'Статус записи: active, completed, expired, cancelled';


--
-- Name: COLUMN enrollments.expires_at; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.enrollments.expires_at IS 'Дата истечения доступа (NULL = бессрочный)';


--
-- Name: COLUMN enrollments.progress_percent; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.enrollments.progress_percent IS 'Процент завершения курса (0-100)';


--
-- Name: COLUMN enrollments.total_lessons; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.enrollments.total_lessons IS 'Общее количество уроков (кэш для быстрого доступа)';


--
-- Name: enrollments_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.enrollments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.enrollments_id_seq OWNER TO nailmastery;

--
-- Name: enrollments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.enrollments_id_seq OWNED BY public.enrollments.id;


--
-- Name: founder_info; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.founder_info (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    greeting character varying(255) DEFAULT 'Привет! Я'::character varying NOT NULL,
    role text NOT NULL,
    image_url text,
    image_upload_path text,
    experience_years integer DEFAULT 0 NOT NULL,
    experience_label character varying(100) DEFAULT 'лет опыта работы'::character varying NOT NULL,
    achievements text[] DEFAULT '{}'::text[] NOT NULL,
    button_text character varying(100) DEFAULT 'Узнать больше'::character varying NOT NULL,
    button_link character varying(255),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.founder_info OWNER TO nailmastery;

--
-- Name: founder_info_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.founder_info_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.founder_info_id_seq OWNER TO nailmastery;

--
-- Name: founder_info_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.founder_info_id_seq OWNED BY public.founder_info.id;


--
-- Name: lesson_progress; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.lesson_progress (
    id integer NOT NULL,
    enrollment_id integer NOT NULL,
    lesson_id integer NOT NULL,
    watched_duration integer DEFAULT 0,
    is_completed boolean DEFAULT false,
    completed_at timestamp with time zone,
    last_watched_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT lesson_progress_watched_duration_check CHECK ((watched_duration >= 0))
);


ALTER TABLE public.lesson_progress OWNER TO nailmastery;

--
-- Name: TABLE lesson_progress; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.lesson_progress IS 'Прогресс прохождения уроков пользователями';


--
-- Name: COLUMN lesson_progress.watched_duration; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.lesson_progress.watched_duration IS 'Время просмотра урока в секундах';


--
-- Name: COLUMN lesson_progress.is_completed; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.lesson_progress.is_completed IS 'Завершен ли урок';


--
-- Name: lesson_progress_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.lesson_progress_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lesson_progress_id_seq OWNER TO nailmastery;

--
-- Name: lesson_progress_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.lesson_progress_id_seq OWNED BY public.lesson_progress.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.schema_migrations (
    id integer NOT NULL,
    migration_name character varying(255) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.schema_migrations OWNER TO nailmastery;

--
-- Name: schema_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.schema_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.schema_migrations_id_seq OWNER TO nailmastery;

--
-- Name: schema_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.schema_migrations_id_seq OWNED BY public.schema_migrations.id;


--
-- Name: seo_settings; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.seo_settings (
    id integer NOT NULL,
    path character varying(500) NOT NULL,
    title character varying(255) NOT NULL,
    description text NOT NULL,
    keywords character varying(500),
    og_title character varying(255),
    og_description text,
    og_image character varying(500),
    og_type character varying(50) DEFAULT 'website'::character varying,
    og_url character varying(500),
    twitter_card character varying(50) DEFAULT 'summary_large_image'::character varying,
    twitter_title character varying(255),
    twitter_description text,
    twitter_image character varying(500),
    canonical_url character varying(500),
    robots character varying(100) DEFAULT 'index, follow'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.seo_settings OWNER TO nailmastery;

--
-- Name: TABLE seo_settings; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.seo_settings IS 'SEO настройки для разных страниц сайта';


--
-- Name: COLUMN seo_settings.path; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.seo_settings.path IS 'Путь страницы (уникальный)';


--
-- Name: COLUMN seo_settings.title; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.seo_settings.title IS 'Title страницы';


--
-- Name: COLUMN seo_settings.description; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.seo_settings.description IS 'Meta description';


--
-- Name: COLUMN seo_settings.og_image; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.seo_settings.og_image IS 'URL изображения для Open Graph';


--
-- Name: seo_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.seo_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.seo_settings_id_seq OWNER TO nailmastery;

--
-- Name: seo_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.seo_settings_id_seq OWNED BY public.seo_settings.id;


--
-- Name: team_members; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.team_members (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(255) NOT NULL,
    bio text NOT NULL,
    image_url text,
    image_upload_path text,
    achievements text[] DEFAULT '{}'::text[] NOT NULL,
    display_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.team_members OWNER TO nailmastery;

--
-- Name: team_members_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.team_members_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.team_members_id_seq OWNER TO nailmastery;

--
-- Name: team_members_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.team_members_id_seq OWNED BY public.team_members.id;


--
-- Name: testimonials; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.testimonials (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(255) NOT NULL,
    avatar character varying(500),
    text text NOT NULL,
    rating integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    avatar_upload_path character varying(500),
    CONSTRAINT testimonials_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.testimonials OWNER TO nailmastery;

--
-- Name: TABLE testimonials; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.testimonials IS 'Таблица отзывов клиентов';


--
-- Name: COLUMN testimonials.name; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.testimonials.name IS 'Имя автора отзыва';


--
-- Name: COLUMN testimonials.role; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.testimonials.role IS 'Роль/должность автора';


--
-- Name: COLUMN testimonials.avatar; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.testimonials.avatar IS 'URL аватара автора';


--
-- Name: COLUMN testimonials.text; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.testimonials.text IS 'Текст отзыва';


--
-- Name: COLUMN testimonials.rating; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.testimonials.rating IS 'Рейтинг от 1 до 5';


--
-- Name: COLUMN testimonials.avatar_upload_path; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.testimonials.avatar_upload_path IS 'Путь к загруженному файлу аватара на сервере';


--
-- Name: testimonials_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.testimonials_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.testimonials_id_seq OWNER TO nailmastery;

--
-- Name: testimonials_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.testimonials_id_seq OWNED BY public.testimonials.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: nailmastery
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(50),
    avatar_url character varying(500),
    avatar_upload_path character varying(255),
    is_active boolean DEFAULT true,
    email_verified boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO nailmastery;

--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON TABLE public.users IS 'Обычные пользователи платформы (студенты)';


--
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.email IS 'Email пользователя (уникальный)';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.password_hash IS 'Хеш пароля (bcrypt)';


--
-- Name: COLUMN users.name; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.name IS 'Имя пользователя';


--
-- Name: COLUMN users.phone; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.phone IS 'Телефон пользователя (опционально)';


--
-- Name: COLUMN users.avatar_url; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.avatar_url IS 'URL аватара (если загружен по ссылке)';


--
-- Name: COLUMN users.avatar_upload_path; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.avatar_upload_path IS 'Путь к загруженному аватару';


--
-- Name: COLUMN users.is_active; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.is_active IS 'Активен ли пользователь';


--
-- Name: COLUMN users.email_verified; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON COLUMN public.users.email_verified IS 'Подтвержден ли email';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: nailmastery
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO nailmastery;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailmastery
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: admin_settings id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.admin_settings ALTER COLUMN id SET DEFAULT nextval('public.admin_settings_id_seq'::regclass);


--
-- Name: admins id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.admins ALTER COLUMN id SET DEFAULT nextval('public.admins_id_seq'::regclass);


--
-- Name: blog_posts id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.blog_posts ALTER COLUMN id SET DEFAULT nextval('public.blog_posts_id_seq'::regclass);


--
-- Name: contacts id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.contacts ALTER COLUMN id SET DEFAULT nextval('public.contacts_id_seq'::regclass);


--
-- Name: course_lessons id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_lessons ALTER COLUMN id SET DEFAULT nextval('public.course_lessons_id_seq'::regclass);


--
-- Name: course_materials id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_materials ALTER COLUMN id SET DEFAULT nextval('public.course_materials_id_seq'::regclass);


--
-- Name: course_modules id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_modules ALTER COLUMN id SET DEFAULT nextval('public.course_modules_id_seq'::regclass);


--
-- Name: course_reviews id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_reviews ALTER COLUMN id SET DEFAULT nextval('public.course_reviews_id_seq'::regclass);


--
-- Name: course_tariffs id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_tariffs ALTER COLUMN id SET DEFAULT nextval('public.course_tariffs_id_seq'::regclass);


--
-- Name: courses id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.courses ALTER COLUMN id SET DEFAULT nextval('public.courses_id_seq'::regclass);


--
-- Name: enrollments id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.enrollments ALTER COLUMN id SET DEFAULT nextval('public.enrollments_id_seq'::regclass);


--
-- Name: founder_info id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.founder_info ALTER COLUMN id SET DEFAULT nextval('public.founder_info_id_seq'::regclass);


--
-- Name: lesson_progress id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.lesson_progress ALTER COLUMN id SET DEFAULT nextval('public.lesson_progress_id_seq'::regclass);


--
-- Name: schema_migrations id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.schema_migrations ALTER COLUMN id SET DEFAULT nextval('public.schema_migrations_id_seq'::regclass);


--
-- Name: seo_settings id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.seo_settings ALTER COLUMN id SET DEFAULT nextval('public.seo_settings_id_seq'::regclass);


--
-- Name: team_members id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.team_members ALTER COLUMN id SET DEFAULT nextval('public.team_members_id_seq'::regclass);


--
-- Name: testimonials id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.testimonials ALTER COLUMN id SET DEFAULT nextval('public.testimonials_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: admin_settings; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.admin_settings (id, setting_key, setting_value, setting_type, description, created_at, updated_at) FROM stdin;
1	theme	light	string	Цвет темы админ-панели (light/dark)	2026-01-07 18:00:20.043656+00	2026-01-07 20:47:48.815858+00
\.


--
-- Data for Name: admins; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.admins (id, email, password_hash, name, created_at, updated_at) FROM stdin;
1	admin@nailmastery.com	$2a$10$5.Uo6TdC.RGOd/BC6M./ROSIsxvSQZEum1TE/yVFnMlv5vNaYl3Li	Администратор	2026-01-07 00:32:26.662808	2026-01-07 00:32:26.662808
\.


--
-- Data for Name: blog_posts; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.blog_posts (id, slug, title, excerpt, content, image_url, image_upload_path, author, author_avatar, author_bio, date, read_time, category, tags, featured, is_active, created_at, updated_at, author_avatar_upload_path, author_id) FROM stdin;
2	gel-polish-guide	Как правильно наносить гель-лак: пошаговая инструкция	Детальный гайд по нанесению гель-лака для начинающих мастеров. Все этапы от подготовки ногтевой пластины до финального покрытия.	["Правильное нанесение гель-лака — это основа качественного маникюра. От того, насколько точно вы выполните каждый этап, зависит долговечность покрытия и его внешний вид.","Первый и самый важный этап — подготовка ногтевой пластины. Необходимо тщательно удалить кутикулу, придать ногтю нужную форму и отполировать поверхность бафом. Это обеспечит лучшее сцепление покрытия с ногтем.","Следующий шаг — обезжиривание. Используйте специальный обезжириватель или клинсер, чтобы удалить все следы масел и влаги с поверхности ногтя. Это критически важно для долговечности покрытия.","Теперь наносим базовое покрытие. Базовый гель создаёт основу для цветного покрытия и обеспечивает его равномерное распределение. Наносите тонким слоем, не затрагивая кутикулу и боковые валики.","Просушите базовый гель в лампе согласно инструкции производителя. Обычно это 30-60 секунд в LED-лампе или 2 минуты в UV-лампе.","Нанесение цветного покрытия — это самый ответственный этап. Наносите гель-лак тонким слоем, начиная от основания ногтя и двигаясь к свободному краю. Избегайте толстых слоёв — лучше нанести два тонких слоя, чем один толстый.","После каждого слоя цвета обязательно просушивайте в лампе. Обычно требуется 60 секунд в LED-лампе.","Финальный этап — топовое покрытие. Топ создаёт защитный слой, придаёт блеск и обеспечивает долговечность маникюра. Наносите так же тонким слоем, не забывая про торцы ногтя.","После финальной просушки удалите липкий слой специальным средством. Ваш маникюр готов!","Помните: качество инструментов и материалов напрямую влияет на результат. Не экономьте на базе и топе — это основа долговечного покрытия."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Мария Соколова	https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop	Специалист по художественному дизайну ногтей. Работает с топовыми салонами Москвы и Санкт-Петербурга.	2024-01-12	8 мин	Обучение	{гель-лак,обучение,техника}	t	t	2026-01-07 03:02:39.234033+00	2026-01-07 03:02:39.234033+00	\N	\N
4	extension-mistakes	Типичные ошибки при наращивании ногтей и как их избежать	Разбираем самые распространённые ошибки начинающих мастеров при наращивании и даём практические советы по их исправлению.	["Наращивание ногтей — это сложная техника, требующая точности и опыта. Многие начинающие мастера допускают типичные ошибки, которые можно легко избежать, зная о них заранее.","Первая и самая распространённая ошибка — неправильная подготовка ногтевой пластины. Многие мастера пренебрегают тщательной обработкой, что приводит к отслоению материала. Важно правильно отполировать поверхность и обезжирить её.","Вторая ошибка — неправильное нанесение материала. Слишком толстый слой геля или акрила приведёт к тому, что ноготь будет выглядеть неестественно и может сломаться. Наносите материал тонкими слоями, давая каждому просохнуть.","Третья ошибка — игнорирование апекса. Апекс — это самая высокая точка ногтя, которая обеспечивает его прочность. Без правильного формирования апекса ноготь будет ломким и недолговечным.","Четвёртая ошибка — неправильная работа с формами. Формы должны плотно прилегать к ногтю, не оставляя зазоров. Неправильная установка формы приведёт к искажению формы ногтя.","Пятая ошибка — недостаточная полировка. После наращивания ноготь нужно тщательно отполировать, чтобы убрать все неровности и придать ему идеальный блеск.","Шестая ошибка — неправильный выбор материала. Не все гели и акрилы подходят для всех типов ногтей. Важно выбирать материал в зависимости от состояния натуральных ногтей клиента.","Седьмая ошибка — игнорирование индивидуальных особенностей. Каждый клиент уникален, и техника наращивания должна адаптироваться под форму и состояние его ногтей.","Восьмая ошибка — спешка. Наращивание требует времени и терпения. Не торопитесь, лучше потратить больше времени, но сделать качественно.","Помните: практика и постоянное обучение — это ключ к мастерству. Не бойтесь ошибок, но учитесь на них и постоянно совершенствуйте свою технику."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Анна Петрова	https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop	Основатель NailArt Academy, международный судья и призёр чемпионатов по nail-art.	2024-01-08	7 мин	Обучение	{наращивание,ошибки,обучение}	f	t	2026-01-07 03:02:39.235911+00	2026-01-07 03:02:39.235911+00	\N	\N
5	color-psychology	Психология цвета в маникюре: как выбрать оттенок	Как цвет лака влияет на настроение и восприятие? Узнайте, какие оттенки подходят для разных случаев и как создать гармоничный образ.	["Цвет играет важную роль в нашем восприятии и настроении. Правильно подобранный оттенок лака может подчеркнуть ваш образ и даже повлиять на эмоциональное состояние.","Красный — это цвет страсти, уверенности и силы. Он идеально подходит для важных встреч и романтических свиданий. Красный маникюр делает образ более смелым и привлекательным.","Розовый ассоциируется с нежностью, романтикой и женственностью. Светлые оттенки розового подходят для повседневного образа, а яркие — для особых случаев.","Бежевый и нюдовый — это классика, которая никогда не выходит из моды. Эти оттенки универсальны и подходят для любого случая. Они создают элегантный и ухоженный вид.","Синий и голубой символизируют спокойствие, надёжность и профессионализм. Эти цвета отлично подходят для деловых встреч и офисного стиля.","Чёрный — это цвет элегантности, загадочности и стиля. Чёрный маникюр подходит для вечерних мероприятий и создания драматичного образа.","Белый символизирует чистоту, свежесть и новое начало. Белый маникюр идеален для лета и особых случаев, таких как свадьба.","Зелёный ассоциируется с природой, гармонией и спокойствием. Зелёные оттенки подходят для создания свежего и естественного образа.","Фиолетовый — это цвет творчества, мистики и роскоши. Фиолетовый маникюр подходит для тех, кто хочет выделиться и проявить свою индивидуальность.","При выборе цвета учитывайте не только психологию, но и свой цветотип, стиль одежды и повод. Правильно подобранный оттенок поможет создать гармоничный и завершённый образ."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Мария Соколова	https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop	Специалист по художественному дизайну ногтей. Работает с топовыми салонами Москвы и Санкт-Петербурга.	2024-01-05	4 мин	Дизайн	{цвет,психология,дизайн}	f	t	2026-01-07 03:02:39.236739+00	2026-01-07 03:02:39.236739+00	\N	\N
6	tools-essentials	Необходимые инструменты для начинающего мастера	Полный список инструментов и материалов, которые понадобятся для начала работы. Что купить в первую очередь, а на чём можно сэкономить.	["Начинающему мастеру маникюра важно правильно выбрать инструменты и материалы. От качества оборудования зависит не только результат работы, но и комфорт клиента.","Основные инструменты, которые понадобятся в первую очередь: кусачки для кутикулы, ножницы для ногтей, пилочки разной зернистости, апельсиновая палочка и пушер для кутикулы.","Аппарат для маникюра — это важная инвестиция. Не стоит покупать самый дешёвый вариант, но и переплачивать за профессиональные модели на старте не нужно. Выберите аппарат средней ценовой категории с хорошими отзывами.","Фрезы для аппарата — это расходный материал, который нужно регулярно обновлять. Начните с базового набора: шарообразная фреза, цилиндрическая и конусная. Этого будет достаточно для начала.","Лампа для сушки гель-лака — обязательный инструмент. LED-лампы более современные и быстрые, но UV-лампы дешевле. Выбирайте в зависимости от бюджета.","Материалы для покрытия: база, топ и цветные гель-лаки. Начните с небольшой палитры базовых цветов, постепенно расширяя коллекцию. Не экономьте на базе и топе — это основа долговечного покрытия.","Средства для стерилизации: спирт, дезинфицирующие растворы, стерилизатор. Безопасность клиентов — это приоритет номер один.","Дополнительные инструменты: кисти для дизайна, стразы, фольга для снятия лака, салфетки без ворса. Эти инструменты можно покупать по мере необходимости.","Организация рабочего места: удобное кресло, хорошее освещение, подставка для инструментов. Комфортное рабочее место повышает качество работы и снижает усталость.","Помните: не нужно покупать всё сразу. Начните с базового набора, а остальное докупайте по мере необходимости и роста клиентской базы."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Елена Новикова	https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop	Эксперт по наращиванию гелем и акрилом. Помогла сотням мастеров освоить сложные техники.	2024-01-03	9 мин	Инструменты	{инструменты,оборудование,"начало работы"}	f	t	2026-01-07 03:02:39.237594+00	2026-01-07 03:02:39.237594+00	\N	\N
7	winter-manicure	Зимний маникюр: идеи и вдохновение	Коллекция идей для зимнего маникюра: от новогодних дизайнов до элегантных классических вариантов. Фото и пошаговые инструкции.	["Зима — это время для экспериментов с маникюром. Новогодние праздники, романтические вечера и просто желание добавить яркости в серые зимние дни — всё это вдохновляет на создание особых дизайнов.","Классический новогодний маникюр включает в себя красные и золотые оттенки. Сочетание этих цветов создаёт праздничное и элегантное настроение. Добавьте немного блёсток или страз для особого блеска.","Белый и серебряный — ещё одна классическая зимняя комбинация. Эти цвета ассоциируются со снегом и зимней свежестью. Идеально подходят для новогодних праздников.","Синий и белый — это сочетание напоминает о зимних пейзажах и создаёт спокойное, умиротворённое настроение. Такой маникюр подходит для повседневного ношения.","Градиенты в зимних оттенках — тренд, который не теряет актуальности. Плавные переходы от тёмно-синего к голубому или от фиолетового к розовому создают эффектный вид.","Геометрические узоры в зимних цветах — современный и стильный вариант. Треугольники, линии и другие фигуры в белом, серебряном или золотом цвете выглядят очень элегантно.","Новогодние символы: ёлочки, снежинки, звёзды — всё это можно изобразить на ногтях. Такие дизайны особенно популярны в преддверии праздников.","Металлические оттенки — золото, серебро, бронза — добавляют роскоши и праздничности. Они отлично сочетаются с любыми цветами и подходят для особых случаев.","Не забывайте про уход за ногтями зимой. Холод и сухой воздух могут негативно влиять на состояние ногтей, поэтому важно использовать увлажняющие средства и защитные покрытия.","Зимний маникюр — это возможность проявить творчество и создать уникальный образ. Экспериментируйте с цветами, техниками и дизайнами, чтобы найти свой стиль."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Анна Петрова	https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop	Основатель NailArt Academy, международный судья и призёр чемпионатов по nail-art.	2024-01-01	5 мин	Дизайн	{зима,"новый год",дизайн}	f	t	2026-01-07 03:02:39.238495+00	2026-01-07 03:02:39.238495+00	\N	\N
8	business-tips	Как открыть свой кабинет маникюра: бизнес-план	Практическое руководство по открытию собственного кабинета маникюра. От выбора локации до привлечения первых клиентов.	["Открытие собственного кабинета маникюра — это серьёзный шаг, требующий тщательной подготовки. Правильное планирование поможет избежать многих ошибок и быстрее выйти на прибыль.","Первое, что нужно сделать — это составить бизнес-план. Определите целевую аудиторию, проанализируйте конкурентов, рассчитайте стартовые затраты и прогнозируемую прибыль.","Выбор локации — один из ключевых факторов успеха. Кабинет должен быть в удобном месте с хорошей проходимостью. Рассмотрите варианты в торговых центрах, жилых районах или рядом с офисными центрами.","Оформление документов: зарегистрируйте ИП или ООО, получите необходимые лицензии и разрешения. Убедитесь, что помещение соответствует санитарным нормам.","Оборудование и материалы: составьте список всего необходимого и рассчитайте стоимость. Не экономьте на качестве — хорошее оборудование окупится быстрее.","Дизайн интерьера: создайте уютную и стильную атмосферу. Клиенты должны чувствовать себя комфортно. Продумайте освещение, цветовую гамму и мебель.","Ценообразование: изучите цены конкурентов и установите свои. Учитывайте затраты на материалы, аренду и желаемую прибыль. Не занижайте цены слишком сильно — это может навредить репутации.","Маркетинг и продвижение: создайте страницы в социальных сетях, запустите рекламу, предложите акции для первых клиентов. Сарафанное радио — лучший способ привлечения клиентов.","Персонал: если планируете нанимать мастеров, тщательно выбирайте кандидатов. Опыт и профессионализм важны, но не менее важны коммуникативные навыки и отношение к клиентам.","Помните: успех приходит не сразу. Будьте готовы к трудностям, постоянно учитесь и совершенствуйтесь. Качественный сервис и внимание к деталям — это залог успешного бизнеса."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Анна Петрова	https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop	Основатель NailArt Academy, международный судья и призёр чемпионатов по nail-art.	2023-12-28	12 мин	Бизнес	{бизнес,кабинет,старт}	f	t	2026-01-07 03:02:39.23948+00	2026-01-07 03:02:39.23948+00	\N	\N
9	nail-art-techniques	5 техник nail-арта, которые должен знать каждый мастер	Осваиваем базовые техники дизайна ногтей: стемпинг, градиент, акварель, инкрустация и объёмный декор. Пошаговые мастер-классы.	["Nail-арт — это искусство, которое требует не только творческого подхода, но и знания различных техник. Освоив базовые техники, вы сможете создавать уникальные и эффектные дизайны.","Стемпинг — это техника нанесения рисунка с помощью специальных пластин и штампа. Это быстрый способ создать сложный дизайн без особых художественных навыков. Главное — правильно подобрать лак и аккуратно нанести рисунок.","Градиент (омбре) — это плавный переход одного цвета в другой. Техника требует определённой сноровки, но результат стоит того. Используйте специальную губку или кисть для создания плавного перехода.","Акварель — это техника создания нежных, размытых рисунков, напоминающих акварельную живопись. Используйте специальные акварельные лаки или разбавляйте обычные лаки для создания нужного эффекта.","Инкрустация — это техника вдавливания различных элементов (стразы, бусины, фольга) в гель или акрил. Это создаёт объёмный и роскошный эффект. Важно правильно закрепить элементы, чтобы они держались долго.","Объёмный декор — это создание трёхмерных элементов на ногте. Используйте специальные гели для моделирования или акрил для создания объёмных фигур, цветов и других элементов.","Каждая техника требует практики и терпения. Начните с простых дизайнов, постепенно усложняя задачи. Изучайте работы других мастеров, вдохновляйтесь и создавайте свои уникальные дизайны.","Важно иметь качественные инструменты и материалы. Хорошие кисти, качественные лаки и гели — это основа успешного nail-арта.","Не бойтесь экспериментировать и пробовать новые техники. Комбинирование различных техник может привести к созданию уникальных и необычных дизайнов.","Помните: nail-арт — это не только техника, но и творчество. Развивайте свой художественный вкус, изучайте тренды и создавайте дизайны, которые будут радовать ваших клиентов."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Мария Соколова	https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop	Специалист по художественному дизайну ногтей. Работает с топовыми салонами Москвы и Санкт-Петербурга.	2023-12-25	10 мин	Дизайн	{nail-арт,техники,дизайн}	f	t	2026-01-07 03:02:39.241128+00	2026-01-07 03:02:39.241128+00	\N	\N
3	nail-care-tips	10 секретов ухода за ногтями в домашних условиях	Простые и эффективные советы по уходу за ногтями, которые помогут сохранить их здоровье и красоту между визитами к мастеру.	["Здоровые и ухоженные ногти — это не только красиво, но и важно для общего состояния организма. Правильный уход поможет сохранить их крепкими и блестящими.","Первое правило — регулярное увлажнение. Используйте масло для кутикулы ежедневно, особенно перед сном. Это поможет предотвратить заусенцы и сухость.","Не забывайте про защиту рук. При работе с бытовой химией всегда надевайте перчатки. Агрессивные вещества могут повредить ногтевую пластину.","Правильное питание играет важную роль. Включите в рацион продукты, богатые кальцием, витаминами группы B и железом. Это поможет укрепить ногти изнутри.","Избегайте частого использования ацетона. Если нужно снять лак, используйте щадящие средства без ацетона или дайте ногтям отдохнуть между покрытиями.","Регулярно подпиливайте ногти, но делайте это правильно. Двигайтесь в одном направлении, не пилите туда-сюда. Это предотвратит расслоение.","Не обрезайте кутикулу слишком агрессивно. Лучше аккуратно отодвинуть её апельсиновой палочкой после размягчения в ванночке.","Используйте укрепляющие лаки и базы. Они помогут защитить ногти и предотвратить ломкость.","Давайте ногтям отдых. Между покрытиями гель-лаком делайте перерывы, чтобы ногтевая пластина могла восстановиться.","И последнее — регулярно посещайте мастера. Профессиональный уход поможет поддерживать ногти в идеальном состоянии."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Елена Новикова	https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop	Эксперт по наращиванию гелем и акрилом. Помогла сотням мастеров освоить сложные техники.	2024-01-08	6 мин	Уход	{уход,здоровье,советы}	f	t	2026-01-07 03:02:39.235016+00	2026-01-07 03:40:44.134847+00	\N	\N
1	top-trends-2024	Топ-10 трендов маникюра 2024: что будет актуально	Разбираем самые актуальные тренды в nail-дизайне на 2024 год. От минималистичных французских маникюров до ярких геометрических принтов.	["2024 год приносит нам множество интересных трендов в мире маникюра. Дизайнеры и мастера экспериментируют с формами, цветами и техниками, создавая уникальные образы.","Одним из главных трендов этого года стал минимализм. Французский маникюр переживает новое рождение — теперь он выполняется в необычных цветовых сочетаниях и с геометрическими элементами.","Ещё один популярный тренд — негативное пространство. Мастера оставляют часть ногтя неокрашенной, создавая интересные визуальные эффекты. Это особенно актуально для летнего сезона.","Геометрические принты также не теряют актуальности. Чёткие линии, треугольники, круги и другие фигуры создают современный и стильный образ.","Цветовая палитра 2024 года включает в себя как нежные пастельные оттенки, так и яркие насыщенные цвета. Особенно популярны оттенки розового, бежевого и глубокого синего.","Объёмный декор продолжает быть актуальным, но теперь он стал более утончённым. Мастера используют стразы, бусины и другие элементы для создания элегантных акцентов.","Градиенты и омбре остаются популярными техниками. Плавные переходы цветов создают эффектный и современный вид.","Металлические акценты — ещё один тренд, который набирает популярность. Золотые и серебряные элементы добавляют роскоши и элегантности.","Не стоит забывать и о классике. Красный и чёрный лаки всегда остаются в тренде и подходят для любого случая.","Важно помнить, что главное в маникюре — это не следование всем трендам одновременно, а создание гармоничного образа, который подходит именно вам."]	https://images.unsplash.com/photo-1604654894610-df63bc536371?w=800&h=600&fit=crop	\N	Анна Петрова	https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop	Основатель NailArt Academy, международный судья и призёр чемпионатов по nail-art.	2024-01-14	5 мин	Тренды	{тренды,дизайн,2024,and}	t	t	2026-01-07 03:02:39.222925+00	2026-01-07 03:06:19.801279+00	\N	\N
10	new-post	Новый	Новый пост блога	["Новый пост блога Новый пост блога Новый пост блога"]	\N	blog-1767807571696-69321297.jpg	Анна Петрова	\N	Международный судья, призёр чемпионатов по nail-art. Обучила более 15 000 мастеров по всему миру.	2026-01-05	5 мин	Тренды	{}	f	t	2026-01-07 03:12:25.958134+00	2026-01-07 17:39:31.737343+00	team-1767753350874-240999520.jpg	1
11	avatar-new-blog	avatar new blog	avatar new blog	["avatar new blog\\navatar new blog\\navatar new blog"]	\N	blog-1767807581814-97714358.jpg	Анна Петрова	\N	Международный судья, призёр чемпионатов по nail-art. Обучила более 15 000 мастеров по всему миру.	2026-01-01	5 мин	Обучение	{"теги теги"}	f	t	2026-01-07 17:20:43.173713+00	2026-01-07 17:39:41.838082+00	team-1767753350874-240999520.jpg	1
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.contacts (id, type, title, content, href, subtitle, icon, display_order, is_active, created_at, updated_at) FROM stdin;
1	phone	Телефон	+7 900 123-45-67	tel:+79001234567	Пн-Вс: 9:00 - 21:00	Phone	0	t	2026-01-07 01:36:47.074542	2026-01-07 01:36:47.074542
2	email	Email	info@nailart-academy.com	mailto:info@nailart-academy.com	Ответим в течение 24 часов	Mail	1	t	2026-01-07 01:36:47.077255	2026-01-07 01:36:47.077255
3	address	Адрес	г. Москва, ул. Примерная, д. 1	\N	Офис по предварительной записи	MapPin	2	t	2026-01-07 01:36:47.078495	2026-01-07 01:36:47.078495
4	social	Социальные сети	@nailart_academy	https://instagram.com/nailart_academy	Следите за новостями	Instagram	3	t	2026-01-07 01:36:47.079971	2026-01-07 01:36:47.079971
\.


--
-- Data for Name: course_lessons; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.course_lessons (id, module_id, title, description, video_url, video_upload_path, preview_video_url, duration, materials, is_preview, order_index, created_at, updated_at) FROM stdin;
85	22	Обзор профессии nail-мастера	В этом уроке вы узнаете о профессии nail-мастера, её перспективах и возможностях заработка. Разберем основные направления в ногтевом сервисе.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1200	[]	t	1	2026-01-07 16:11:36.233963+00	2026-01-07 16:11:36.233963+00
86	22	Организация рабочего места	Узнайте, как правильно организовать рабочее место nail-мастера для максимального комфорта и эффективности работы.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	900	[]	t	2	2026-01-07 16:11:36.235605+00	2026-01-07 16:11:36.235605+00
87	22	Инструменты и материалы	Подробный обзор всех необходимых инструментов и материалов для работы nail-мастера. Как выбрать качественные материалы.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1500	[]	f	3	2026-01-07 16:11:36.236481+00	2026-01-07 16:11:36.236481+00
88	22	Санитарные нормы и стерилизация	Изучите правила санитарии и стерилизации инструментов. Требования СЭС к работе nail-мастера.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1800	[]	f	4	2026-01-07 16:11:36.237201+00	2026-01-07 16:11:36.237201+00
89	23	Строение ногтя	Анатомия ногтя: строение, зоны роста, функции. Понимание структуры ногтя — основа качественной работы мастера.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1000	[]	f	1	2026-01-07 16:11:36.239971+00	2026-01-07 16:11:36.239971+00
90	23	Опил ногтевой пластины	Техники опила ногтей различной формы. Правильный выбор пилки и направления движения для идеального результата.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2000	[]	f	2	2026-01-07 16:11:36.240767+00	2026-01-07 16:11:36.240767+00
91	23	Техника обрезного маникюра	Пошаговая техника выполнения обрезного маникюра. Работа с инструментами, безопасность, идеальный результат.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2400	[]	f	3	2026-01-07 16:11:36.241907+00	2026-01-07 16:11:36.241907+00
92	23	Работа с кутикулой	Техники удаления кутикулы: обрезная и европейская. Работа с проблемной кутикулой.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1800	[]	f	4	2026-01-07 16:11:36.24254+00	2026-01-07 16:11:36.24254+00
93	24	Выбор аппарата и фрез	Как выбрать аппарат для маникюра. Виды фрез, их назначение и правила использования.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1500	[]	f	1	2026-01-07 16:11:36.244025+00	2026-01-07 16:11:36.244025+00
94	24	Техники работы с аппаратом	Основные техники работы с аппаратом: скорость, давление, угол наклона. Практические упражнения.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	3000	[]	f	2	2026-01-07 16:11:36.245065+00	2026-01-07 16:11:36.245065+00
95	24	Комбинированная техника	Сочетание классического и аппаратного маникюра для достижения идеального результата.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2500	[]	f	3	2026-01-07 16:11:36.245865+00	2026-01-07 16:11:36.245865+00
96	24	Работа с проблемными ногтями	Особенности работы с тонкими, ломкими ногтями и другими проблемами ногтевой пластины.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2200	[]	f	4	2026-01-07 16:11:36.246492+00	2026-01-07 16:11:36.246492+00
97	25	Подготовка ногтя к покрытию	Правильная подготовка ногтевой пластины — залог долгоносимости покрытия. Все этапы подготовки.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1200	[]	f	1	2026-01-07 16:11:36.248297+00	2026-01-07 16:11:36.248297+00
98	25	Нанесение базы и цвета	Техника нанесения базового и цветного покрытия. Выравнивание ногтевой пластины, работа с пигментированными гель-лаками.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2800	[]	f	2	2026-01-07 16:11:36.249204+00	2026-01-07 16:11:36.249204+00
99	25	Идеальные торцы и блики	Запечатывание торцов для долгоносимости покрытия. Создание идеальных бликов на топе.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2000	[]	f	3	2026-01-07 16:11:36.24997+00	2026-01-07 16:11:36.24997+00
100	25	Снятие покрытия	Безопасное снятие гель-лакового покрытия без повреждения ногтевой пластины.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1500	[]	f	4	2026-01-07 16:11:36.250558+00	2026-01-07 16:11:36.250558+00
101	26	Введение в аппаратный маникюр	История аппаратного маникюра, его преимущества и особенности. Когда применять аппаратную технику.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1000	[]	f	1	2026-01-07 16:11:36.259473+00	2026-01-07 16:11:36.259473+00
102	26	Выбор аппарата и фрез	Критерии выбора аппарата для маникюра. Обзор популярных моделей. Виды фрез и их назначение.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2000	[]	f	2	2026-01-07 16:11:36.259991+00	2026-01-07 16:11:36.259991+00
103	26	Настройка аппарата	Правильная настройка аппарата: мощность, скорость вращения. Регулировка под разные задачи.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1500	[]	f	3	2026-01-07 16:11:36.260574+00	2026-01-07 16:11:36.260574+00
104	26	Безопасность и санитария	Правила безопасной работы с аппаратом. Стерилизация фрез и насадок. Профилактика травм.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1200	[]	f	4	2026-01-07 16:11:36.261063+00	2026-01-07 16:11:36.261063+00
105	27	Виды фрез и их применение	Подробный обзор всех видов фрез: алмазные, керамические, твердосплавные. Когда какую фрезу использовать.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1800	[]	f	1	2026-01-07 16:11:36.262141+00	2026-01-07 16:11:36.262141+00
106	27	Техника опила ногтевой пластины	Аппаратный опил ногтевой пластины: выбор фрезы, скорость, техника движения. Создание идеальной формы.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2500	[]	f	2	2026-01-07 16:11:36.262614+00	2026-01-07 16:11:36.262614+00
107	27	Работа с кутикулой аппаратом	Поднятие и удаление кутикулы аппаратом. Выбор правильной фрезы и техника безопасной работы.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2200	[]	f	3	2026-01-07 16:11:36.263116+00	2026-01-07 16:11:36.263116+00
108	27	Обработка боковых валиков	Техника обработки боковых валиков аппаратом. Работа в труднодоступных местах.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2000	[]	f	4	2026-01-07 16:11:36.263671+00	2026-01-07 16:11:36.263671+00
109	28	Тонкие и ломкие ногти	Особенности работы аппаратом с тонкими и ломкими ногтями. Выбор фрез и техника безопасной обработки.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2000	[]	f	1	2026-01-07 16:11:36.265587+00	2026-01-07 16:11:36.265587+00
110	28	Вросшие ногти	Работа с вросшими ногтями: диагностика, техника коррекции аппаратом, профилактика.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2400	[]	f	2	2026-01-07 16:11:36.266085+00	2026-01-07 16:11:36.266085+00
111	28	Грибковые поражения	Определение грибковых поражений. Правила работы с такими ногтями, санитария и стерилизация.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	1800	[]	f	3	2026-01-07 16:11:36.266776+00	2026-01-07 16:11:36.266776+00
112	28	Травмированные ногти	Работа с травмированными ногтями аппаратом. Восстановление ногтевой пластины.	https://www.youtube.com/watch?v=dQw4w9WgXcQ	\N	\N	2000	[]	f	4	2026-01-07 16:11:36.268056+00	2026-01-07 16:11:36.268056+00
\.


--
-- Data for Name: course_materials; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.course_materials (id, course_id, name, price_info, link, display_order, created_at) FROM stdin;
28	7	Аппарат для маникюра	(от 100 €)	\N	1	2026-01-07 16:11:36.254066+00
29	7	Набор фрез	(от 20 €)	\N	2	2026-01-07 16:11:36.254833+00
30	7	Лампа для сушки	(от 30 €)	\N	3	2026-01-07 16:11:36.255314+00
31	7	База, топ, гель-лаки	(от 50 €)	\N	4	2026-01-07 16:11:36.255775+00
32	7	Инструменты	(от 30 €)	\N	5	2026-01-07 16:11:36.256928+00
33	8	Аппарат для маникюра	(от 100 €)	\N	1	2026-01-07 16:11:36.270663+00
34	8	Набор фрез (базовый)	(от 25 €)	\N	2	2026-01-07 16:11:36.271175+00
35	8	Антисептик и стерилизатор	(от 15 €)	\N	3	2026-01-07 16:11:36.271655+00
36	8	Крем для рук	(от 10 €)	\N	4	2026-01-07 16:11:36.27217+00
\.


--
-- Data for Name: course_modules; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.course_modules (id, course_id, title, description, order_index, created_at, updated_at) FROM stdin;
22	7	Модуль 1. Введение в профессию	\N	1	2026-01-07 16:11:36.232389+00	2026-01-07 16:11:36.232389+00
23	7	Модуль 2. Классический маникюр	\N	2	2026-01-07 16:11:36.238799+00	2026-01-07 16:11:36.238799+00
24	7	Модуль 3. Аппаратный маникюр	\N	3	2026-01-07 16:11:36.243194+00	2026-01-07 16:11:36.243194+00
25	7	Модуль 4. Покрытие гель-лаком	\N	4	2026-01-07 16:11:36.247157+00	2026-01-07 16:11:36.247157+00
26	8	Модуль 1. Основы аппаратного маникюра	\N	1	2026-01-07 16:11:36.25882+00	2026-01-07 16:11:36.25882+00
27	8	Модуль 2. Техники работы с фрезами	\N	2	2026-01-07 16:11:36.261549+00	2026-01-07 16:11:36.261549+00
28	8	Модуль 3. Работа с проблемными ногтями	\N	3	2026-01-07 16:11:36.264621+00	2026-01-07 16:11:36.264621+00
\.


--
-- Data for Name: course_reviews; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.course_reviews (id, course_id, user_id, enrollment_id, rating, comment, is_approved, is_featured, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: course_tariffs; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.course_tariffs (id, course_id, tariff_type, name, price, old_price, features, not_included, is_popular, is_active, display_order, homework_reviews_limit, curator_support_months, created_at, updated_at) FROM stdin;
19	7	self	Самостоятельный	129.00	199.00	["Доступ ко всем урокам", "Бессрочный доступ", "Закрытый чат", "Сертификат"]	["Проверка ДЗ", "Обратная связь"]	f	t	1	\N	\N	2026-01-07 16:11:36.251095+00	2026-01-07 16:11:36.251095+00
20	7	curator	С куратором	199.00	299.00	["Всё из тарифа 'Самостоятельный'", "Проверка 16 домашних заданий", "Обратная связь в течение 24 часов", "2 месяца поддержки куратора"]	[]	t	t	2	16	2	2026-01-07 16:11:36.252738+00	2026-01-07 16:11:36.252738+00
21	7	vip	VIP	349.00	499.00	["Всё из тарифа 'С куратором'", "Индивидуальные созвоны с экспертом", "Помощь в поиске первых клиентов", "Пожизненная поддержка", "Бонусные мастер-классы"]	[]	f	t	3	\N	\N	2026-01-07 16:11:36.253448+00	2026-01-07 16:11:36.253448+00
22	8	self	Самостоятельный	99.00	149.00	["Доступ ко всем урокам", "Бессрочный доступ", "Закрытый чат", "Сертификат"]	["Проверка ДЗ", "Обратная связь"]	f	t	1	\N	\N	2026-01-07 16:11:36.268608+00	2026-01-07 16:11:36.268608+00
23	8	curator	С куратором	149.00	199.00	["Всё из тарифа 'Самостоятельный'", "Проверка 12 домашних заданий", "Обратная связь в течение 24 часов", "2 месяца поддержки куратора"]	[]	t	t	2	12	2	2026-01-07 16:11:36.269286+00	2026-01-07 16:11:36.269286+00
24	8	vip	VIP	249.00	349.00	["Всё из тарифа 'С куратором'", "Индивидуальные созвоны с экспертом", "Помощь в поиске первых клиентов", "Пожизненная поддержка", "Бонусные мастер-классы"]	[]	f	t	3	\N	\N	2026-01-07 16:11:36.269908+00	2026-01-07 16:11:36.269908+00
\.


--
-- Data for Name: courses; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.courses (id, slug, title, subtitle, description, image_url, image_upload_path, video_preview_url, level, category, duration, students_count, rating, reviews_count, instructor_id, is_active, is_featured, is_new, display_order, includes, created_at, updated_at) FROM stdin;
7	basic-manicure	Базовый курс маникюра	От новичка до профессионала за 4 недели	Комплексная программа обучения для тех, кто хочет освоить профессию nail-мастера с нуля. Вы научитесь выполнять классический и аппаратный маникюр, работать с гель-лаком и создавать идеальное покрытие.	\N	/uploads/course-1767804852919-793401914.jpg		beginner	basics	4 недели	2847	4.90	456	2	t	t	t	1	["32 видеоурока в HD качестве", "Проверка домашних заданий куратором", "Сертификат о прохождении курса", "Бессрочный доступ к материалам", "Закрытый чат с участниками", "Список материалов для работы"]	2026-01-07 16:11:36.229268+00	2026-01-07 16:54:12.957781+00
8	hardware-manicure	Аппаратный маникюр	Профессиональное владение аппаратом за 3 недели	Профессиональное владение аппаратом. Фрезы, техники, работа с проблемными ногтями. Научитесь выполнять аппаратный маникюр на высоком уровне.	\N	/uploads/course-1767812052767-363859726.jpg		beginner	hardware	3 недели	1892	4.70	234	2	t	f	t	2	["24 видеоурока в HD качестве", "Проверка домашних заданий куратором", "Сертификат о прохождении курса", "Бессрочный доступ к материалам", "Закрытый чат с участниками", "Список материалов для работы"]	2026-01-07 16:11:36.257989+00	2026-01-07 19:11:09.937855+00
\.


--
-- Data for Name: enrollments; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.enrollments (id, user_id, course_id, tariff_id, status, purchased_at, expires_at, started_at, completed_at, progress_percent, lessons_completed, total_lessons, payment_id, payment_status, amount_paid, created_at, updated_at) FROM stdin;
3	1	7	20	active	2026-01-07 16:11:36.709091+00	\N	2026-01-07 16:11:36.709091+00	\N	6	1	16	\N	paid	0.00	2026-01-07 16:11:36.709091+00	2026-01-07 16:32:45.739147+00
4	1	8	23	active	2026-01-07 20:21:22.77801+00	\N	2026-01-07 20:21:22.77801+00	\N	0	0	12	pi_3Sn3EJGosYpy72KU0VXpdHJM	paid	149.00	2026-01-07 20:21:22.77801+00	2026-01-07 20:21:22.77801+00
5	2	8	23	active	2026-01-07 20:23:19.144548+00	\N	2026-01-07 20:23:19.144548+00	\N	0	0	12	pi_3Sn3GCGosYpy72KU1OPzTiOR	paid	149.00	2026-01-07 20:23:19.144548+00	2026-01-07 20:23:19.144548+00
\.


--
-- Data for Name: founder_info; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.founder_info (id, name, greeting, role, image_url, image_upload_path, experience_years, experience_label, achievements, button_text, button_link, is_active, created_at, updated_at) FROM stdin;
1	Анна Петрова	Привет! Я	Основатель NailArt Academy, международный судья и призёр чемпионатов по nail-art	\N	founder-1767752598516-163409087.jpg	12	лет опыта работы	{"Обучила более 15 000 мастеров по всему миру","Автор уникальных техник, признанных международным сообществом","Постоянный эксперт beauty-изданий","Амбассадор ведущих брендов nail-индустрии"}	Узнать больше	/about	t	2026-01-07 02:17:46.138518+00	2026-01-07 02:31:27.742035+00
\.


--
-- Data for Name: lesson_progress; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.lesson_progress (id, enrollment_id, lesson_id, watched_duration, is_completed, completed_at, last_watched_at, created_at, updated_at) FROM stdin;
1	3	85	1200	t	\N	2026-01-07 16:32:45.730682+00	2026-01-07 16:32:45.730682+00	2026-01-07 16:32:45.730682+00
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.schema_migrations (id, migration_name, executed_at) FROM stdin;
1	0000_create_migrations_table	2026-01-07 00:12:47.059462
3	0001_create_admins_table	2026-01-07 00:32:17.407678
4	0002_create_testimonials_table	2026-01-07 00:48:21.872704
6	0003_add_avatar_upload_to_testimonials	2026-01-07 01:02:49.264798
7	0004_create_contacts_table	2026-01-07 01:34:55.294926
8	0005_create_founder_info_table	2026-01-07 02:16:17.105541
9	0006_create_about_tables	2026-01-07 02:24:17.956473
10	0006_create_team_members_table	2026-01-07 02:35:10.373667
11	0007_create_blog_posts_table	2026-01-07 02:53:48.852263
12	0008_add_author_avatar_upload_to_blog_posts	2026-01-07 03:13:50.484
13	0009_add_indexes_for_performance	2026-01-07 03:53:36.612346
14	0010_create_seo_settings_table	2026-01-07 04:04:32.056796
16	0011_create_users_table	2026-01-07 14:01:37.494778
17	0012_create_courses_table	2026-01-07 14:31:35.201676
18	0013_create_course_modules_table	2026-01-07 14:31:35.224483
19	0014_create_course_lessons_table	2026-01-07 14:31:35.23217
20	0015_create_course_tariffs_table	2026-01-07 14:31:35.239651
21	0016_create_course_materials_table	2026-01-07 14:31:35.250206
22	0017_create_enrollments_table	2026-01-07 14:31:35.258688
23	0018_create_lesson_progress_table	2026-01-07 14:31:35.270562
24	0019_create_course_reviews_table	2026-01-07 14:31:35.280299
25	0020_add_courses_indexes_for_performance	2026-01-07 14:31:35.293584
26	0021_add_lesson_video_and_description	2026-01-07 15:39:21.06206
27	0021_add_author_id_to_blog_posts	2026-01-07 17:04:47.428505
28	0022_create_admin_settings_table	2026-01-07 18:00:20.043656
\.


--
-- Data for Name: seo_settings; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.seo_settings (id, path, title, description, keywords, og_title, og_description, og_image, og_type, og_url, twitter_card, twitter_title, twitter_description, twitter_image, canonical_url, robots, created_at, updated_at) FROM stdin;
4	/blog	Блог о маникюре | NailArt Academy	Полезные статьи о маникюре, трендах, техниках и уходе за ногтями. Советы от профессионалов, обзоры инструментов и материалов, истории успеха учеников.	блог о маникюре, статьи про маникюр, тренды маникюра, техники маникюра, уход за ногтями, советы nail мастера	Блог о маникюре | NailArt Academy	Полезные статьи о маникюре, трендах, техниках и уходе за ногтями. Советы от профессионалов и обзоры инструментов.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	Блог о маникюре | NailArt Academy	Полезные статьи о маникюре, трендах, техниках и уходе за ногтями.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.282856+00	2026-01-07 14:09:36.180914+00
2	/courses	Курсы маникюра | NailArt Academy	Выберите курс маникюра для себя: базовый курс, наращивание гелем, nail-дизайн. Онлайн обучение с поддержкой куратора и бессрочным доступом к материалам.	курсы маникюра, обучение маникюру онлайн, базовый курс маникюра, наращивание ногтей, nail дизайн, курсы гель лака	Курсы маникюра | NailArt Academy	Выберите курс маникюра для себя: базовый курс, наращивание гелем, nail-дизайн. Онлайн обучение с поддержкой куратора.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	Курсы маникюра | NailArt Academy	Выберите курс маникюра для себя: базовый курс, наращивание гелем, nail-дизайн.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.277942+00	2026-01-07 14:09:36.176455+00
3	/about	О нас | NailArt Academy — Школа маникюра	NailArt Academy — онлайн-школа маникюра с 2018 года. Более 15 000 выпускников, 50+ курсов, 98% довольных учеников. Опытные преподаватели и индивидуальный подход.	о школе маникюра, nailart academy, история школы, преподаватели маникюра, отзывы учеников, команда школы	О нас | NailArt Academy — Школа маникюра	NailArt Academy — онлайн-школа маникюра с 2018 года. Более 15 000 выпускников, 50+ курсов, 98% довольных учеников.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	О нас | NailArt Academy	NailArt Academy — онлайн-школа маникюра с 2018 года. Более 15 000 выпускников.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.280242+00	2026-01-07 14:09:36.179184+00
5	/schedule	Расписание вебинаров и мастер-классов | NailArt Academy	Расписание бесплатных вебинаров и платных мастер-классов по маникюру. Запишитесь на онлайн-мероприятия и получите новые знания от опытных мастеров.	вебинары маникюра, мастер классы маникюра, расписание вебинаров, онлайн обучение маникюру, бесплатные вебинары	Расписание вебинаров и мастер-классов | NailArt Academy	Расписание бесплатных вебинаров и платных мастер-классов по маникюру. Запишитесь на онлайн-мероприятия.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	Расписание вебинаров | NailArt Academy	Расписание бесплатных вебинаров и платных мастер-классов по маникюру.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.289335+00	2026-01-07 14:09:36.183208+00
6	/contacts	Контакты | NailArt Academy	Свяжитесь с нами: телефон, email, адрес, социальные сети. Ответим на все вопросы о курсах, записи на вебинары и обучении маникюру.	контакты nailart academy, связаться со школой, телефон школы маникюра, email школы, адрес школы	Контакты | NailArt Academy	Свяжитесь с нами: телефон, email, адрес, социальные сети. Ответим на все вопросы о курсах и обучении.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	Контакты | NailArt Academy	Свяжитесь с нами: телефон, email, адрес, социальные сети.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.291248+00	2026-01-07 14:09:36.184512+00
7	/faq	Часто задаваемые вопросы | NailArt Academy	Ответы на популярные вопросы о курсах маникюра, обучении, оплате, сертификатах и программах. Все что нужно знать перед началом обучения.	FAQ маникюра, вопросы о курсах, часто задаваемые вопросы, ответы о школе маникюра, вопросы об обучении	Часто задаваемые вопросы | NailArt Academy	Ответы на популярные вопросы о курсах маникюра, обучении, оплате, сертификатах и программах.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	FAQ | NailArt Academy	Ответы на популярные вопросы о курсах маникюра, обучении, оплате и сертификатах.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.292553+00	2026-01-07 14:09:36.186709+00
8	/terms	Публичная оферта | NailArt Academy	Публичная оферта и условия использования сайта NailArt Academy. Правила предоставления услуг, оплаты курсов и возврата средств.	публичная оферта, условия использования, правила школы, договор оферты, условия оплаты	Публичная оферта | NailArt Academy	Публичная оферта и условия использования сайта NailArt Academy. Правила предоставления услуг и оплаты курсов.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	Публичная оферта | NailArt Academy	Публичная оферта и условия использования сайта NailArt Academy.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.293632+00	2026-01-07 14:09:36.188098+00
1	/	NailArt Academy — Онлайн-курсы маникюра	Онлайн-школа маникюра для начинающих и профессионалов. Освойте профессию nail-мастера и начните зарабатывать от 1 000 € в месяц. Видеоуроки, поддержка куратора, сертификат.	онлайн курсы маникюра, обучение маникюру, nail мастер, гель лак, наращивание ногтей, маникюр с нуля, школа маникюра	NailArt Academy — Онлайн-курсы маникюра	Онлайн-школа маникюра для начинающих и профессионалов. Освойте профессию nail-мастера и начните зарабатывать от 1 000 € в месяц.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	NailArt Academy — Онлайн-курсы маникюра	Онлайн-школа маникюра для начинающих и профессионалов. Освойте профессию nail-мастера.	https://lovable.dev/opengraph-image-p98pqg.png	\N	index, follow	2026-01-07 12:45:17.270618+00	2026-01-07 14:09:36.172526+00
17	/login	Вход в личный кабинет | NailArt Academy	Войдите в личный кабинет NailArt Academy для доступа к вашим курсам, урокам, домашним заданиям и сертификатам. Регистрация новых пользователей.	вход в личный кабинет, регистрация, авторизация, личный кабинет студента, доступ к курсам	Вход в личный кабинет | NailArt Academy	Войдите в личный кабинет NailArt Academy для доступа к вашим курсам, урокам и сертификатам.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	Вход в личный кабинет | NailArt Academy	Войдите в личный кабинет NailArt Academy для доступа к вашим курсам и урокам.	https://lovable.dev/opengraph-image-p98pqg.png	\N	noindex, nofollow	2026-01-07 14:09:36.189541+00	2026-01-07 14:09:36.189541+00
18	/dashboard	Личный кабинет | NailArt Academy	Личный кабинет студента NailArt Academy. Доступ к вашим курсам, прогресс обучения, домашние задания, сертификаты и статистика.	личный кабинет, мои курсы, прогресс обучения, домашние задания, сертификаты, статистика студента	Личный кабинет | NailArt Academy	Личный кабинет студента NailArt Academy. Доступ к вашим курсам, прогресс обучения и сертификаты.	https://lovable.dev/opengraph-image-p98pqg.png	website	\N	summary_large_image	Личный кабинет | NailArt Academy	Личный кабинет студента NailArt Academy. Доступ к вашим курсам и прогресс обучения.	https://lovable.dev/opengraph-image-p98pqg.png	\N	noindex, nofollow	2026-01-07 14:09:36.192755+00	2026-01-07 14:09:36.192755+00
19	/blog/new-post	Новый | NailArt Academy	Новый пост блога	Тренды	Новый	Новый пост блога	/uploads/blog/blog-1767807571696-69321297.jpg	article	\N	summary_large_image	Новый	Новый пост блога	/uploads/blog/blog-1767807571696-69321297.jpg	\N	index, follow	2026-01-07 17:20:05.602308+00	2026-01-07 17:39:31.73938+00
20	/blog/avatar-new-blog	avatar new blog | NailArt Academy	avatar new blog	теги теги	avatar new blog	avatar new blog	/uploads/blog/blog-1767807581814-97714358.jpg	article	\N	summary_large_image	avatar new blog	avatar new blog	/uploads/blog/blog-1767807581814-97714358.jpg	\N	index, follow	2026-01-07 17:20:43.177315+00	2026-01-07 17:39:41.840016+00
\.


--
-- Data for Name: team_members; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.team_members (id, name, role, bio, image_url, image_upload_path, achievements, display_order, is_active, created_at, updated_at) FROM stdin;
2	Мария Соколова	Преподаватель дизайна	Специалист по художественному дизайну ногтей. Работает с топовыми салонами Москвы и Санкт-Петербурга.	https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop	\N	{"8 лет в профессии","Мастер международного класса","Победитель конкурсов дизайна"}	2	t	2026-01-07 02:35:19.859248+00	2026-01-07 02:35:19.859248+00
3	Елена Новикова	Преподаватель наращивания	Эксперт по наращиванию гелем и акрилом. Помогла сотням мастеров освоить сложные техники.	https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=400&h=400&fit=crop	\N	{"10 лет опыта","Сертифицированный тренер","Автор курсов по архитектуре"}	3	t	2026-01-07 02:35:19.861228+00	2026-01-07 02:35:19.861228+00
1	Анна Петрова	Основатель и главный преподаватель	Международный судья, призёр чемпионатов по nail-art. Обучила более 15 000 мастеров по всему миру.	\N	team-1767753350874-240999520.jpg	{"12 лет опыта в индустрии","Автор уникальных техник","Эксперт beauty-изданий"}	1	t	2026-01-07 02:35:19.850392+00	2026-01-07 02:35:50.915882+00
\.


--
-- Data for Name: testimonials; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.testimonials (id, name, role, avatar, text, rating, created_at, updated_at, avatar_upload_path) FROM stdin;
1	Анна Козлова	Выпускница базового курса	https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop	Благодаря курсу я смогла уволиться с нелюбимой работы и открыть свой кабинет. Уже через 3 месяца полностью окупила обучение!	5	2026-01-07 00:51:06.555833	2026-01-07 00:51:06.555833	\N
2	Мария Соколова	Мастер маникюра	https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop	Курс по дизайну полностью изменил мой подход к работе. Клиенты в восторге, записываются за месяц вперёд!	5	2026-01-07 00:51:06.56067	2026-01-07 00:51:06.56067	\N
3	Елена Новикова	Начинающий мастер	https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=100&h=100&fit=crop	Очень понравился формат обучения. Куратор всегда на связи, материалы понятные даже для новичка.	5	2026-01-07 00:51:06.563194	2026-01-07 00:51:06.563194	\N
4	Ольга Петрова	Владелец салона	https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop	Прошла все курсы от базового до VIP. Теперь у меня свой салон с 5 мастерами. Качество обучения на высшем уровне!	5	2026-01-07 00:51:06.565444	2026-01-07 00:51:06.565444	\N
5	Татьяна Иванова	Выпускница курса наращивания	https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop	Долго искала хороший курс по наращиванию. Здесь всё объясняют детально, с примерами. Теперь делаю идеальные ногти!	5	2026-01-07 00:51:06.56854	2026-01-07 00:51:06.56854	\N
6	Светлана Волкова	Мастер nail-арта	https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop	Курс по дизайну открыл для меня новые техники. Теперь я создаю уникальные дизайны, которых нет ни у кого в городе.	5	2026-01-07 00:51:06.572489	2026-01-07 00:51:06.572489	\N
7	Ирина Смирнова	Выпускница аппаратного маникюра	https://images.unsplash.com/photo-1529626455594-4ff0802cfb7e?w=100&h=100&fit=crop	Боялась работать с аппаратом, но курс развеял все страхи. Теперь аппаратный маникюр - моя специализация.	5	2026-01-07 00:51:06.57552	2026-01-07 00:51:06.57552	\N
9	Юлия Морозова	Мастер с опытом	https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop	Уже работала мастером, но хотела повысить квалификацию. Курсы помогли освоить новые техники и увеличить доход.	4	2026-01-07 00:51:06.579253	2026-01-07 00:53:42.617121	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: nailmastery
--

COPY public.users (id, email, password_hash, name, phone, avatar_url, avatar_upload_path, is_active, email_verified, created_at, updated_at) FROM stdin;
1	nik.urs@icloud.com	$2a$10$VMDezr7d4Z75Dl4ZoqN8FOB2GZn9ZzKWyego.sEleWhyn7EhaVORC	Nikita Ursulenco	\N	\N	\N	t	f	2026-01-07 14:03:54.343388+00	2026-01-07 18:41:47.001509+00
2	nikita.ursulenco@gmail.com	$2a$10$Z8nSCVVX5AE1BIIqQi1JqeNEdhlanYKKltQZLnIa8prWFXtXMUi8S	Vikoriia Lakatosh	\N	\N	\N	t	f	2026-01-07 20:22:07.394146+00	2026-01-07 20:22:07.394146+00
\.


--
-- Name: admin_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.admin_settings_id_seq', 1, true);


--
-- Name: admins_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.admins_id_seq', 1, true);


--
-- Name: blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.blog_posts_id_seq', 11, true);


--
-- Name: contacts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.contacts_id_seq', 4, true);


--
-- Name: course_lessons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.course_lessons_id_seq', 112, true);


--
-- Name: course_materials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.course_materials_id_seq', 36, true);


--
-- Name: course_modules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.course_modules_id_seq', 28, true);


--
-- Name: course_reviews_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.course_reviews_id_seq', 1, false);


--
-- Name: course_tariffs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.course_tariffs_id_seq', 24, true);


--
-- Name: courses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.courses_id_seq', 8, true);


--
-- Name: enrollments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.enrollments_id_seq', 5, true);


--
-- Name: founder_info_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.founder_info_id_seq', 1, true);


--
-- Name: lesson_progress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.lesson_progress_id_seq', 1, true);


--
-- Name: schema_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.schema_migrations_id_seq', 28, true);


--
-- Name: seo_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.seo_settings_id_seq', 27, true);


--
-- Name: team_members_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.team_members_id_seq', 3, true);


--
-- Name: testimonials_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.testimonials_id_seq', 9, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailmastery
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: admin_settings admin_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.admin_settings
    ADD CONSTRAINT admin_settings_pkey PRIMARY KEY (id);


--
-- Name: admin_settings admin_settings_setting_key_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.admin_settings
    ADD CONSTRAINT admin_settings_setting_key_key UNIQUE (setting_key);


--
-- Name: admins admins_email_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_email_key UNIQUE (email);


--
-- Name: admins admins_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.admins
    ADD CONSTRAINT admins_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_pkey PRIMARY KEY (id);


--
-- Name: blog_posts blog_posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_slug_key UNIQUE (slug);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: course_lessons course_lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_lessons
    ADD CONSTRAINT course_lessons_pkey PRIMARY KEY (id);


--
-- Name: course_materials course_materials_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_materials
    ADD CONSTRAINT course_materials_pkey PRIMARY KEY (id);


--
-- Name: course_modules course_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_modules
    ADD CONSTRAINT course_modules_pkey PRIMARY KEY (id);


--
-- Name: course_reviews course_reviews_course_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_course_id_user_id_key UNIQUE (course_id, user_id);


--
-- Name: course_reviews course_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_pkey PRIMARY KEY (id);


--
-- Name: course_tariffs course_tariffs_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_tariffs
    ADD CONSTRAINT course_tariffs_pkey PRIMARY KEY (id);


--
-- Name: courses courses_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_pkey PRIMARY KEY (id);


--
-- Name: courses courses_slug_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_slug_key UNIQUE (slug);


--
-- Name: enrollments enrollments_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_pkey PRIMARY KEY (id);


--
-- Name: enrollments enrollments_user_id_course_id_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_user_id_course_id_key UNIQUE (user_id, course_id);


--
-- Name: founder_info founder_info_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.founder_info
    ADD CONSTRAINT founder_info_pkey PRIMARY KEY (id);


--
-- Name: lesson_progress lesson_progress_enrollment_id_lesson_id_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_enrollment_id_lesson_id_key UNIQUE (enrollment_id, lesson_id);


--
-- Name: lesson_progress lesson_progress_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_migration_name_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_migration_name_key UNIQUE (migration_name);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (id);


--
-- Name: seo_settings seo_settings_path_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.seo_settings
    ADD CONSTRAINT seo_settings_path_key UNIQUE (path);


--
-- Name: seo_settings seo_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.seo_settings
    ADD CONSTRAINT seo_settings_pkey PRIMARY KEY (id);


--
-- Name: team_members team_members_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.team_members
    ADD CONSTRAINT team_members_pkey PRIMARY KEY (id);


--
-- Name: testimonials testimonials_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.testimonials
    ADD CONSTRAINT testimonials_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: courses_slug_unique; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE UNIQUE INDEX courses_slug_unique ON public.courses USING btree (slug);


--
-- Name: idx_admin_settings_key; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_admin_settings_key ON public.admin_settings USING btree (setting_key);


--
-- Name: idx_admins_email; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_admins_email ON public.admins USING btree (email);


--
-- Name: idx_blog_posts_author_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_blog_posts_author_id ON public.blog_posts USING btree (author_id);


--
-- Name: idx_blog_posts_category; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_blog_posts_category ON public.blog_posts USING btree (category);


--
-- Name: idx_blog_posts_category_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_blog_posts_category_active ON public.blog_posts USING btree (category, is_active) WHERE (is_active = true);


--
-- Name: idx_blog_posts_date; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_blog_posts_date ON public.blog_posts USING btree (date DESC);


--
-- Name: idx_blog_posts_featured; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_blog_posts_featured ON public.blog_posts USING btree (featured);


--
-- Name: idx_blog_posts_is_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_blog_posts_is_active ON public.blog_posts USING btree (is_active);


--
-- Name: idx_blog_posts_slug; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_blog_posts_slug ON public.blog_posts USING btree (slug);


--
-- Name: idx_contacts_display_order; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_contacts_display_order ON public.contacts USING btree (display_order);


--
-- Name: idx_contacts_is_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_contacts_is_active ON public.contacts USING btree (is_active);


--
-- Name: idx_course_lessons_is_preview; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_lessons_is_preview ON public.course_lessons USING btree (is_preview);


--
-- Name: idx_course_lessons_module_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_lessons_module_id ON public.course_lessons USING btree (module_id);


--
-- Name: idx_course_lessons_order; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_lessons_order ON public.course_lessons USING btree (module_id, order_index);


--
-- Name: idx_course_materials_course_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_materials_course_id ON public.course_materials USING btree (course_id);


--
-- Name: idx_course_materials_display_order; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_materials_display_order ON public.course_materials USING btree (course_id, display_order);


--
-- Name: idx_course_modules_course_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_modules_course_id ON public.course_modules USING btree (course_id);


--
-- Name: idx_course_modules_order; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_modules_order ON public.course_modules USING btree (course_id, order_index);


--
-- Name: idx_course_reviews_course_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_reviews_course_id ON public.course_reviews USING btree (course_id);


--
-- Name: idx_course_reviews_enrollment_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_reviews_enrollment_id ON public.course_reviews USING btree (enrollment_id);


--
-- Name: idx_course_reviews_is_approved; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_reviews_is_approved ON public.course_reviews USING btree (is_approved);


--
-- Name: idx_course_reviews_is_featured; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_reviews_is_featured ON public.course_reviews USING btree (is_featured);


--
-- Name: idx_course_reviews_rating; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_reviews_rating ON public.course_reviews USING btree (course_id, rating);


--
-- Name: idx_course_reviews_user_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_reviews_user_id ON public.course_reviews USING btree (user_id);


--
-- Name: idx_course_tariffs_course_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_tariffs_course_id ON public.course_tariffs USING btree (course_id);


--
-- Name: idx_course_tariffs_display_order; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_tariffs_display_order ON public.course_tariffs USING btree (course_id, display_order);


--
-- Name: idx_course_tariffs_is_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_tariffs_is_active ON public.course_tariffs USING btree (is_active);


--
-- Name: idx_course_tariffs_tariff_type; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_course_tariffs_tariff_type ON public.course_tariffs USING btree (tariff_type);


--
-- Name: idx_courses_active_featured; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_active_featured ON public.courses USING btree (is_active, is_featured) WHERE (is_active = true);


--
-- Name: INDEX idx_courses_active_featured; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON INDEX public.idx_courses_active_featured IS 'Индекс для быстрого поиска активных и featured курсов';


--
-- Name: idx_courses_category; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_category ON public.courses USING btree (category);


--
-- Name: idx_courses_category_level; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_category_level ON public.courses USING btree (category, level) WHERE (is_active = true);


--
-- Name: INDEX idx_courses_category_level; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON INDEX public.idx_courses_category_level IS 'Индекс для фильтрации по категории и уровню';


--
-- Name: idx_courses_display_order; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_display_order ON public.courses USING btree (display_order);


--
-- Name: idx_courses_display_order_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_display_order_active ON public.courses USING btree (display_order, is_active) WHERE (is_active = true);


--
-- Name: idx_courses_instructor_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_instructor_id ON public.courses USING btree (instructor_id);


--
-- Name: idx_courses_is_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_is_active ON public.courses USING btree (is_active);


--
-- Name: idx_courses_is_featured; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_is_featured ON public.courses USING btree (is_featured);


--
-- Name: idx_courses_level; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_level ON public.courses USING btree (level);


--
-- Name: idx_courses_slug; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_courses_slug ON public.courses USING btree (slug);


--
-- Name: idx_enrollments_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_enrollments_active ON public.enrollments USING btree (user_id, course_id) WHERE ((status)::text = 'active'::text);


--
-- Name: INDEX idx_enrollments_active; Type: COMMENT; Schema: public; Owner: nailmastery
--

COMMENT ON INDEX public.idx_enrollments_active IS 'Индекс для быстрого поиска активных записей пользователя';


--
-- Name: idx_enrollments_course_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_enrollments_course_id ON public.enrollments USING btree (course_id);


--
-- Name: idx_enrollments_payment_status; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_enrollments_payment_status ON public.enrollments USING btree (payment_status);


--
-- Name: idx_enrollments_status; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_enrollments_status ON public.enrollments USING btree (status);


--
-- Name: idx_enrollments_tariff_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_enrollments_tariff_id ON public.enrollments USING btree (tariff_id);


--
-- Name: idx_enrollments_user_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_enrollments_user_id ON public.enrollments USING btree (user_id);


--
-- Name: idx_founder_info_is_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_founder_info_is_active ON public.founder_info USING btree (is_active);


--
-- Name: idx_lesson_progress_completed; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_lesson_progress_completed ON public.lesson_progress USING btree (enrollment_id, is_completed) WHERE (is_completed = true);


--
-- Name: idx_lesson_progress_enrollment_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_lesson_progress_enrollment_id ON public.lesson_progress USING btree (enrollment_id);


--
-- Name: idx_lesson_progress_enrollment_lesson; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_lesson_progress_enrollment_lesson ON public.lesson_progress USING btree (enrollment_id, lesson_id);


--
-- Name: idx_lesson_progress_is_completed; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_lesson_progress_is_completed ON public.lesson_progress USING btree (is_completed);


--
-- Name: idx_lesson_progress_lesson_id; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_lesson_progress_lesson_id ON public.lesson_progress USING btree (lesson_id);


--
-- Name: idx_migrations_name; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_migrations_name ON public.schema_migrations USING btree (migration_name);


--
-- Name: idx_seo_settings_path; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_seo_settings_path ON public.seo_settings USING btree (path);


--
-- Name: idx_team_members_display_order; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_team_members_display_order ON public.team_members USING btree (display_order);


--
-- Name: idx_team_members_is_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_team_members_is_active ON public.team_members USING btree (is_active);


--
-- Name: idx_testimonials_created_at; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_testimonials_created_at ON public.testimonials USING btree (created_at DESC);


--
-- Name: idx_testimonials_rating; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_testimonials_rating ON public.testimonials USING btree (rating);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_is_active; Type: INDEX; Schema: public; Owner: nailmastery
--

CREATE INDEX idx_users_is_active ON public.users USING btree (is_active);


--
-- Name: blog_posts blog_posts_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.blog_posts
    ADD CONSTRAINT blog_posts_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.team_members(id) ON DELETE SET NULL;


--
-- Name: course_lessons course_lessons_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_lessons
    ADD CONSTRAINT course_lessons_module_id_fkey FOREIGN KEY (module_id) REFERENCES public.course_modules(id) ON DELETE CASCADE;


--
-- Name: course_materials course_materials_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_materials
    ADD CONSTRAINT course_materials_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_modules course_modules_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_modules
    ADD CONSTRAINT course_modules_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_reviews course_reviews_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: course_reviews course_reviews_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.enrollments(id);


--
-- Name: course_reviews course_reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_reviews
    ADD CONSTRAINT course_reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: course_tariffs course_tariffs_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.course_tariffs
    ADD CONSTRAINT course_tariffs_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: courses courses_instructor_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.courses
    ADD CONSTRAINT courses_instructor_id_fkey FOREIGN KEY (instructor_id) REFERENCES public.team_members(id) ON DELETE SET NULL;


--
-- Name: enrollments enrollments_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_course_id_fkey FOREIGN KEY (course_id) REFERENCES public.courses(id) ON DELETE CASCADE;


--
-- Name: enrollments enrollments_tariff_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_tariff_id_fkey FOREIGN KEY (tariff_id) REFERENCES public.course_tariffs(id);


--
-- Name: enrollments enrollments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.enrollments
    ADD CONSTRAINT enrollments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: lesson_progress lesson_progress_enrollment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_enrollment_id_fkey FOREIGN KEY (enrollment_id) REFERENCES public.enrollments(id) ON DELETE CASCADE;


--
-- Name: lesson_progress lesson_progress_lesson_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailmastery
--

ALTER TABLE ONLY public.lesson_progress
    ADD CONSTRAINT lesson_progress_lesson_id_fkey FOREIGN KEY (lesson_id) REFERENCES public.course_lessons(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 561UK4z7GOZGPETxf6O54oTPhVALExz1CGBz8tmu10PG3TsXKTBfG3QvSeeTCw4

